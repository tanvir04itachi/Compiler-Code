using namespace std;
void re1();
