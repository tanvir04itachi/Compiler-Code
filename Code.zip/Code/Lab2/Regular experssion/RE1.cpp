#include <iostream>
#include "RE1.h"
using namespace std;
void re1()
{
    string input;
    int i;
    bool valid = true;
    cout << "Enter a string to check RE = a*: ";
    cin >> input;
    for (i = 0; i < input.length(); i++)
    {
        if (input[i] != 'a')
        {
            valid = false;
            break;
        }
    }
    if (valid)
        cout << "Accepted" << endl;
    else
        cout << "Rejected" << endl;
}
