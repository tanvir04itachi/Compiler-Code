using namespace std;
void re3();
