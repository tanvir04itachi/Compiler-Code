#include <iostream>
#include "RE1.h"
#include "RE2.h"
#include "RE3.h"
#include "RE4.h"
using namespace std;
int main()
{
    int choice;
    cout << "Regular Expression Checker" << endl;
    cout << "1. RE1 = a*" << endl;
    cout << "2. RE2 = (a + b)" << endl;
    cout << "3. RE3 = (a + b)*" << endl;
    cout << "4. RE4 = (a + b)*c(a + b)(bb + aa)" << endl;
    cout << "Enter your choice: ";
    cin >> choice;

    switch (choice)
    {
        case 1:
            re1();
            break;

        case 2:
            re2();
            break;

        case 3:
            re3();
            break;

        case 4:
            re4();
            break;

        default:
            cout << "Invalid choice" << endl;
    }
    return 0;
}
