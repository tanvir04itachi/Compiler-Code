using namespace std;
void re4();
