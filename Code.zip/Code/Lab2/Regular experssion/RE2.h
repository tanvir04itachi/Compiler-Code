using namespace std;
void re2();
