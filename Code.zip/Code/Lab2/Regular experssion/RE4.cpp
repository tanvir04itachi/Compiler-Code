#include <iostream>
#include "RE4.h"
using namespace std;
void re4()
{
    string s;
    int i = 0;
    cout << "Enter a string to check RE = (a+b)*c(a+b)(bb+aa): ";
    cin >> s;
    while (i < s.length() && (s[i] == 'a' || s[i] == 'b'))
    {
        i++;
    }
    if (i >= s.length() || s[i] != 'c')
    {
        cout << "Rejected" << endl;
        return;
    }
    i++;
    if (i >= s.length() || (s[i] != 'a' && s[i] != 'b'))
    {
        cout << "Rejected" << endl;
        return;
    }
    i++;
    if (i + 1 >= s.length())
    {
        cout << "Rejected" << endl;
        return;
    }

    if ((s[i] == 'a' && s[i+1] == 'a') ||
        (s[i] == 'b' && s[i+1] == 'b'))
    {
        i += 2;
    }
    else
    {
        cout << "Rejected" << endl;
        return;
    }
    if (i == s.length())
        cout << "Accepted" << endl;
    else
        cout << "Rejected" << endl;
}
