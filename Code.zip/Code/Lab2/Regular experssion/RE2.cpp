#include <iostream>
#include "RE2.h"
using namespace std;
void re2()
{
    string input;
    cout << "Enter a string to check RE = (a + b): ";
    cin >> input;
    if (input.length() == 1 && (input[0] == 'a' || input[0] == 'b'))
    {
        cout << "Accepted" << endl;
    }
    else
    {
        cout << "Rejected" << endl;
    }
}
