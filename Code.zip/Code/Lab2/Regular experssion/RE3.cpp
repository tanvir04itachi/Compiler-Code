#include <iostream>
#include "RE3.h"
using namespace std;
void re3()
{
    string input;
    bool valid = true;

    cout << "Enter a string to check RE = (a + b)*: ";
    cin >> input;
    for (int i = 0; i < input.length(); i++)
    {
        if (input[i] != 'a' && input[i] != 'b')
        {
            valid = false;
            break;
        }
    }
    if (valid)
        cout << "Accepted" << endl;
    else
        cout << "Rejected" << endl;
}
