using namespace std;
int min();

