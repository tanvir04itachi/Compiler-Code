#include <iostream>
#include "1.h"
#include "4.h"
#include "5.h"
#include "6.h"
#include "7.h"

using namespace std;

int main() {
    int choice;
    cout << "4. Check Identifier" << endl;
    cout << "5. Find Average of Array" << endl;
    cout << "6. Find Min and Max of Array" << endl;
    cout << "7. Concatenate Full Name" << endl;
    cout << "Enter your choice (4-7): ";
    cin >> choice;

    switch (choice) {
        case 4:
            main4();
            break;
        case 5:
            main5();
            break;
        case 6:
            main6();
            break;
        case 7:
            main7();
            break;
        default:
            cout << "Invalid choice! Please enter 4-7." << endl;
    }

    return 0;
}
