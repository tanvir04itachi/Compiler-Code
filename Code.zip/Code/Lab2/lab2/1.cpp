
#include <iostream>

using namespace std;

int min()
{
    cout << "Hello" << endl;
    return 0;
}
